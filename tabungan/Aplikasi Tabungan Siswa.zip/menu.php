<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
			<a class="navbar-brand" href="rully-studio.blogspot.com">Home</a>
		</div>
		<ul class="nav navbar-nav">
			<li><a href="siswa.html">Siswa</a></li>
			<li><a href="tabungan.html">Tabungan</a></li> 
		</ul>
	</div>
</nav>